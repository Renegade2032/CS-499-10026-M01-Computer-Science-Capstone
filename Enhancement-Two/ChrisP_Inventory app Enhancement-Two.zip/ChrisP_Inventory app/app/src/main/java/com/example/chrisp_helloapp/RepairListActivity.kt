package com.example.chrisp_helloapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RepairListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repair_list)

        val repairList = findViewById<ListView>(R.id.listRepairs)
        val noRepairsText = findViewById<TextView>(R.id.textNoRepairs)
        val backButton = findViewById<Button>(R.id.buttonBackRepairs)
        val searchBox = findViewById<EditText>(R.id.editSearchRepairs)
        val statusFilter = findViewById<Spinner>(R.id.spinnerStatusFilter)
        val sortSpinner = findViewById<Spinner>(R.id.spinnerSortRepairs)

        // Get all saved repairs
        val repairs = RepairRepository.getRepairs(this)

        // Repairs currently displayed on screen
        var filteredRepairs = repairs.toList()

        // Status filter choices
        val statusChoices = arrayOf(
            "All Statuses",
            "Received",
            "Diagnosing",
            "Waiting for Parts",
            "In Repair",
            "Ready for Pickup",
            "Completed"
        )

        val statusAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            statusChoices
        )

        statusAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        statusFilter.adapter = statusAdapter

        // Sort choices
        val sortChoices = arrayOf(
            "Priority: Highest First",
            "Priority: Lowest First",
            "Customer: A-Z",
            "Customer: Z-A"
        )

        val sortAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            sortChoices
        )

        sortAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        sortSpinner.adapter = sortAdapter

        // Display repairs on screen
        fun displayRepairs(repairsToDisplay: List<RepairTicket>) {

            filteredRepairs = repairsToDisplay

            if (repairsToDisplay.isEmpty()) {

                noRepairsText.visibility = View.VISIBLE
                repairList.visibility = View.GONE

            } else {

                noRepairsText.visibility = View.GONE
                repairList.visibility = View.VISIBLE

                val repairDisplayList = repairsToDisplay.map { repair ->
                    "${repair.customerName}\n" +
                            "${repair.deviceType} - ${repair.deviceModel}\n" +
                            "Status: ${repair.status}\n" +
                            "Priority: ${repair.priority}"
                }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_list_item_1,
                    repairDisplayList
                )

                repairList.adapter = adapter
            }
        }

        // Search, filter, and sorting algorithm
        fun applyFiltersAndSort() {

            val searchText = searchBox.text.toString().trim()
            val selectedStatus = statusFilter.selectedItem.toString()
            val selectedSort = sortSpinner.selectedItem.toString()

            // First search and filter the repairs
            var results = repairs.filter { repair ->

                val matchesSearch =
                    searchText.isEmpty() ||
                            repair.customerName.contains(
                                searchText,
                                ignoreCase = true
                            ) ||
                            repair.phone.contains(
                                searchText,
                                ignoreCase = true
                            ) ||
                            repair.deviceType.contains(
                                searchText,
                                ignoreCase = true
                            ) ||
                            repair.deviceModel.contains(
                                searchText,
                                ignoreCase = true
                            )

                val matchesStatus =
                    selectedStatus == "All Statuses" ||
                            repair.status == selectedStatus

                matchesSearch && matchesStatus
            }

            // Give each priority a numeric value for sorting
            fun priorityValue(priority: String): Int {
                return when (priority) {
                    "Urgent" -> 4
                    "High" -> 3
                    "Normal" -> 2
                    "Low" -> 1
                    else -> 0
                }
            }

            // Sort the filtered results
            results = when (selectedSort) {

                "Priority: Highest First" ->
                    results.sortedByDescending {
                        priorityValue(it.priority)
                    }

                "Priority: Lowest First" ->
                    results.sortedBy {
                        priorityValue(it.priority)
                    }

                "Customer: A-Z" ->
                    results.sortedBy {
                        it.customerName.lowercase()
                    }

                "Customer: Z-A" ->
                    results.sortedByDescending {
                        it.customerName.lowercase()
                    }

                else -> results
            }

            displayRepairs(results)
        }

        // Search whenever text changes
        searchBox.addTextChangedListener(object : TextWatcher {

            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
                applyFiltersAndSort()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

        // Filter whenever status changes
        statusFilter.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFiltersAndSort()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }

        // Sort whenever sort option changes
        sortSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFiltersAndSort()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                }
            }

        // Initial display
        applyFiltersAndSort()

        // Open the correct repair from the sorted/filtered list
        repairList.setOnItemClickListener { _, _, position, _ ->

            val selectedRepair = filteredRepairs[position]

            val originalPosition = repairs.indexOf(selectedRepair)

            val intent = Intent(
                this@RepairListActivity,
                RepairDetailActivity::class.java
            )

            intent.putExtra(
                "repair_position",
                originalPosition
            )

            startActivity(intent)
        }

        // Back to dashboard
        backButton.setOnClickListener {
            finish()
        }
    }
}