package com.example.chrisp_helloapp

import android.content.Context

object RepairRepository {

    // Add a new repair to the database
    fun addRepair(context: Context, repair: RepairTicket): Boolean {

        val databaseHelper = DatabaseHelper(context)

        val result = databaseHelper.addRepair(
            repair.customerName,
            repair.phone,
            repair.deviceType,
            repair.deviceModel,
            repair.problemDescription,
            repair.status,
            repair.technicianNotes,
            repair.priority
        )

        databaseHelper.close()

        return result != -1L
    }

    // Get all repairs from the database
    fun getRepairs(context: Context): List<RepairTicket> {

        val repairs = mutableListOf<RepairTicket>()

        val databaseHelper = DatabaseHelper(context)
        val cursor = databaseHelper.getAllRepairs()

        while (cursor.moveToNext()) {

            val repair = RepairTicket(

                // Permanent database ID
                id = cursor.getLong(
                    cursor.getColumnIndexOrThrow("id")
                ),

                customerName = cursor.getString(
                    cursor.getColumnIndexOrThrow("customer_name")
                ),

                phone = cursor.getString(
                    cursor.getColumnIndexOrThrow("phone")
                ),

                deviceType = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_type")
                ),

                deviceModel = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_model")
                ),

                problemDescription = cursor.getString(
                    cursor.getColumnIndexOrThrow("problem_description")
                ),

                status = cursor.getString(
                    cursor.getColumnIndexOrThrow("status")
                ),

                technicianNotes = cursor.getString(
                    cursor.getColumnIndexOrThrow("technician_notes")
                ),

                priority = cursor.getString(
                    cursor.getColumnIndexOrThrow("priority")
                )
            )

            repairs.add(repair)
        }

        cursor.close()
        databaseHelper.close()

        return repairs
    }

    // Update an existing repair in the database
    fun updateRepair(context: Context, repair: RepairTicket): Boolean {

        // A valid saved repair must have a database ID
        if (repair.id == -1L) {
            return false
        }

        val databaseHelper = DatabaseHelper(context)

        val result = databaseHelper.updateRepair(
            repair.id,
            repair.customerName,
            repair.phone,
            repair.deviceType,
            repair.deviceModel,
            repair.problemDescription,
            repair.status,
            repair.technicianNotes,
            repair.priority
        )

        databaseHelper.close()

        return result
    }
}