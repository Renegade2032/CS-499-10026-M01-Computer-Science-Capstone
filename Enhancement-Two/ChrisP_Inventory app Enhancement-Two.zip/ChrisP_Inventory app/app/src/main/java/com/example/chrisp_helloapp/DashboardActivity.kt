package com.example.chrisp_helloapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Connect dashboard buttons
        val buttonNewRepair = findViewById<Button>(R.id.buttonNewRepair)
        val buttonExistingRepairs = findViewById<Button>(R.id.buttonExistingRepairs)
        val buttonPartsInventory = findViewById<Button>(R.id.buttonPartsInventory)

        // Open New Repair screen
        buttonNewRepair.setOnClickListener {
            val intent = Intent(
                this@DashboardActivity,
                NewRepairActivity::class.java
            )
            startActivity(intent)
        }

        // Open Existing Repairs screen
        buttonExistingRepairs.setOnClickListener {
            val intent = Intent(
                this@DashboardActivity,
                RepairListActivity::class.java
            )
            startActivity(intent)
        }

        // Open original Parts Inventory screen
        buttonPartsInventory.setOnClickListener {
            val intent = Intent(
                this@DashboardActivity,
                InventoryActivity::class.java
            )
            startActivity(intent)
        }
    }
}