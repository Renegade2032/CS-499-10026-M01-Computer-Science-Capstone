package com.example.chrisp_helloapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Central SQLite helper for login credentials,
 * inventory data, and repair tickets.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_tracking.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_INVENTORY = "inventory";
    public static final String TABLE_REPAIRS = "repairs";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL)");

        // Inventory table
        db.execSQL("CREATE TABLE " + TABLE_INVENTORY + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0))");

        // Repairs table
        db.execSQL("CREATE TABLE " + TABLE_REPAIRS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "customer_name TEXT NOT NULL, " +
                "phone TEXT NOT NULL, " +
                "device_type TEXT NOT NULL, " +
                "device_model TEXT NOT NULL, " +
                "problem_description TEXT NOT NULL, " +
                "status TEXT NOT NULL, " +
                "technician_notes TEXT, " +
                "priority TEXT NOT NULL DEFAULT 'Normal')");
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        // Upgrade from version 1 to version 2
        // without deleting existing users or inventory.
        if (oldVersion < 2) {

            db.execSQL("CREATE TABLE IF NOT EXISTS " +
                    TABLE_REPAIRS + " (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "customer_name TEXT NOT NULL, " +
                    "phone TEXT NOT NULL, " +
                    "device_type TEXT NOT NULL, " +
                    "device_model TEXT NOT NULL, " +
                    "problem_description TEXT NOT NULL, " +
                    "status TEXT NOT NULL, " +
                    "technician_notes TEXT, " +
                    "priority TEXT NOT NULL DEFAULT 'Normal')");
        }
    }

    /**
     * Creates a user.
     * Returns false when the username already exists.
     */
    public boolean createUser(
            String username,
            String password) {

        ContentValues values = new ContentValues();

        values.put("username", username.trim());
        values.put("password_hash", hashPassword(password));

        return getWritableDatabase().insert(
                TABLE_USERS,
                null,
                values
        ) != -1;
    }

    /**
     * Checks the supplied login against the users table.
     */
    public boolean validateLogin(
            String username,
            String password) {

        Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"id"},
                "username = ? AND password_hash = ?",
                new String[]{
                        username.trim(),
                        hashPassword(password)
                },
                null,
                null,
                null
        );

        boolean valid = cursor.moveToFirst();

        cursor.close();

        return valid;
    }

    // Get all inventory items
    public Cursor getAllInventory() {

        return getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{
                        "id",
                        "item_name",
                        "quantity"
                },
                null,
                null,
                null,
                null,
                "item_name COLLATE NOCASE ASC"
        );
    }

    // Add an inventory item
    public long addItem(
            String itemName,
            int quantity) {

        ContentValues values = new ContentValues();

        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    // Update an inventory item
    public boolean updateItem(
            long id,
            String itemName,
            int quantity) {

        ContentValues values = new ContentValues();

        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // Update inventory quantity
    public boolean updateQuantity(
            long id,
            int quantity) {

        ContentValues values = new ContentValues();

        values.put(
                "quantity",
                Math.max(0, quantity)
        );

        return getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // Delete an inventory item
    public boolean deleteItem(long id) {

        return getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // --------------------------------------------------
    // REPAIR DATABASE METHODS
    // --------------------------------------------------

    // Save a new repair ticket
    public long addRepair(
            String customerName,
            String phone,
            String deviceType,
            String deviceModel,
            String problemDescription,
            String status,
            String technicianNotes,
            String priority) {

        ContentValues values = new ContentValues();

        values.put(
                "customer_name",
                customerName.trim()
        );

        values.put(
                "phone",
                phone.trim()
        );

        values.put(
                "device_type",
                deviceType.trim()
        );

        values.put(
                "device_model",
                deviceModel.trim()
        );

        values.put(
                "problem_description",
                problemDescription.trim()
        );

        values.put(
                "status",
                status
        );

        values.put(
                "technician_notes",
                technicianNotes
        );

        values.put(
                "priority",
                priority
        );

        return getWritableDatabase().insert(
                TABLE_REPAIRS,
                null,
                values
        );
    }

    // Get all saved repair tickets
    public Cursor getAllRepairs() {

        return getReadableDatabase().query(
                TABLE_REPAIRS,
                new String[]{
                        "id",
                        "customer_name",
                        "phone",
                        "device_type",
                        "device_model",
                        "problem_description",
                        "status",
                        "technician_notes",
                        "priority"
                },
                null,
                null,
                null,
                null,
                "id ASC"
        );
    }

    // Update an existing repair ticket
    public boolean updateRepair(
            long id,
            String customerName,
            String phone,
            String deviceType,
            String deviceModel,
            String problemDescription,
            String status,
            String technicianNotes,
            String priority) {

        ContentValues values = new ContentValues();

        values.put(
                "customer_name",
                customerName.trim()
        );

        values.put(
                "phone",
                phone.trim()
        );

        values.put(
                "device_type",
                deviceType.trim()
        );

        values.put(
                "device_model",
                deviceModel.trim()
        );

        values.put(
                "problem_description",
                problemDescription.trim()
        );

        values.put(
                "status",
                status
        );

        values.put(
                "technician_notes",
                technicianNotes
        );

        values.put(
                "priority",
                priority
        );

        return getWritableDatabase().update(
                TABLE_REPAIRS,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // --------------------------------------------------
    // PASSWORD HASHING
    // --------------------------------------------------

    private String hashPassword(String password) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            byte[] hash = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8)
            );

            StringBuilder output =
                    new StringBuilder();

            for (byte b : hash) {
                output.append(
                        String.format("%02x", b)
                );
            }

            return output.toString();

        } catch (NoSuchAlgorithmException e) {

            // SHA-256 is required by Android/Java.
            // This fallback prevents a crash.
            return password;
        }
    }
}