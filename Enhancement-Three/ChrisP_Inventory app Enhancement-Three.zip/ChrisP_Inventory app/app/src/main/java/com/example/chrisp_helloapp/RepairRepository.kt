package com.example.chrisp_helloapp

import android.content.Context

object RepairRepository {

    // Add a new repair to the database
    fun addRepair(context: Context, repair: RepairTicket): Boolean {

        val databaseHelper = DatabaseHelper(context)

        val result = databaseHelper.addRepair(
            repair.customerName,
            repair.phone,
            repair.deviceType,
            repair.deviceModel,
            repair.problemDescription,
            repair.status,
            repair.technicianNotes,
            repair.priority
        )

        databaseHelper.close()

        // Save the permanent database ID into the repair object
        if (result != -1L) {
            repair.id = result
            return true
        }

        return false
    }

    // Get all repairs from the database
    fun getRepairs(context: Context): List<RepairTicket> {

        val repairs = mutableListOf<RepairTicket>()

        val databaseHelper = DatabaseHelper(context)
        val cursor = databaseHelper.getAllRepairs()

        while (cursor.moveToNext()) {

            val repair = RepairTicket(

                // Permanent database ID
                id = cursor.getLong(
                    cursor.getColumnIndexOrThrow("id")
                ),

                customerName = cursor.getString(
                    cursor.getColumnIndexOrThrow("customer_name")
                ),

                phone = cursor.getString(
                    cursor.getColumnIndexOrThrow("phone")
                ),

                deviceType = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_type")
                ),

                deviceModel = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_model")
                ),

                problemDescription = cursor.getString(
                    cursor.getColumnIndexOrThrow("problem_description")
                ),

                status = cursor.getString(
                    cursor.getColumnIndexOrThrow("status")
                ),

                technicianNotes = cursor.getString(
                    cursor.getColumnIndexOrThrow("technician_notes")
                ),

                priority = cursor.getString(
                    cursor.getColumnIndexOrThrow("priority")
                ),

                createdAt = cursor.getLong(
                    cursor.getColumnIndexOrThrow("created_at")
                ),

                updatedAt = cursor.getLong(
                    cursor.getColumnIndexOrThrow("updated_at")
                )
            )

            repairs.add(repair)
        }

        cursor.close()
        databaseHelper.close()

        return repairs
    }

    // Search repairs directly in the SQLite database
    fun searchRepairs(
        context: Context,
        searchText: String
    ): List<RepairTicket> {

        val repairs = mutableListOf<RepairTicket>()

        val databaseHelper = DatabaseHelper(context)

        val cursor =
            databaseHelper.searchRepairs(searchText)

        while (cursor.moveToNext()) {

            val repair = RepairTicket(

                id = cursor.getLong(
                    cursor.getColumnIndexOrThrow("id")
                ),

                customerName = cursor.getString(
                    cursor.getColumnIndexOrThrow("customer_name")
                ),

                phone = cursor.getString(
                    cursor.getColumnIndexOrThrow("phone")
                ),

                deviceType = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_type")
                ),

                deviceModel = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_model")
                ),

                problemDescription = cursor.getString(
                    cursor.getColumnIndexOrThrow("problem_description")
                ),

                status = cursor.getString(
                    cursor.getColumnIndexOrThrow("status")
                ),

                technicianNotes = cursor.getString(
                    cursor.getColumnIndexOrThrow("technician_notes")
                ),

                priority = cursor.getString(
                    cursor.getColumnIndexOrThrow("priority")
                ),

                createdAt = cursor.getLong(
                    cursor.getColumnIndexOrThrow("created_at")
                ),

                updatedAt = cursor.getLong(
                    cursor.getColumnIndexOrThrow("updated_at")
                )
            )

            repairs.add(repair)
        }

        cursor.close()
        databaseHelper.close()

        return repairs
    }

    // Get one repair using its permanent database ID
    fun getRepairById(
        context: Context,
        repairId: Long
    ): RepairTicket? {

        val databaseHelper = DatabaseHelper(context)

        val cursor =
            databaseHelper.getRepairById(repairId)

        var repair: RepairTicket? = null

        if (cursor.moveToFirst()) {

            repair = RepairTicket(

                id = cursor.getLong(
                    cursor.getColumnIndexOrThrow("id")
                ),

                customerName = cursor.getString(
                    cursor.getColumnIndexOrThrow("customer_name")
                ),

                phone = cursor.getString(
                    cursor.getColumnIndexOrThrow("phone")
                ),

                deviceType = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_type")
                ),

                deviceModel = cursor.getString(
                    cursor.getColumnIndexOrThrow("device_model")
                ),

                problemDescription = cursor.getString(
                    cursor.getColumnIndexOrThrow("problem_description")
                ),

                status = cursor.getString(
                    cursor.getColumnIndexOrThrow("status")
                ),

                technicianNotes = cursor.getString(
                    cursor.getColumnIndexOrThrow("technician_notes")
                ),

                priority = cursor.getString(
                    cursor.getColumnIndexOrThrow("priority")
                ),

                createdAt = cursor.getLong(
                    cursor.getColumnIndexOrThrow("created_at")
                ),

                updatedAt = cursor.getLong(
                    cursor.getColumnIndexOrThrow("updated_at")
                )
            )
        }

        cursor.close()
        databaseHelper.close()

        return repair
    }

    // Update an existing repair in the database
    fun updateRepair(
        context: Context,
        repair: RepairTicket
    ): Boolean {

        // A valid saved repair must have a database ID
        if (repair.id == -1L) {
            return false
        }

        val databaseHelper = DatabaseHelper(context)

        val result = databaseHelper.updateRepair(
            repair.id,
            repair.customerName,
            repair.phone,
            repair.deviceType,
            repair.deviceModel,
            repair.problemDescription,
            repair.status,
            repair.technicianNotes,
            repair.priority
        )

        databaseHelper.close()

        return result
    }

    // Delete a repair using its permanent database ID
    fun deleteRepair(
        context: Context,
        repairId: Long
    ): Boolean {

        if (repairId == -1L) {
            return false
        }

        val databaseHelper = DatabaseHelper(context)

        val result =
            databaseHelper.deleteRepair(repairId)

        databaseHelper.close()

        return result
    }
}