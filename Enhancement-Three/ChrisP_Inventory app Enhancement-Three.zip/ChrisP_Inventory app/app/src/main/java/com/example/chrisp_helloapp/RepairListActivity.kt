package com.example.chrisp_helloapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RepairListActivity : AppCompatActivity() {

    // Store the repairs outside onCreate so they can be refreshed
    private var repairs: List<RepairTicket> = emptyList()

    private var filteredRepairs: List<RepairTicket> = emptyList()

    private lateinit var repairList: ListView
    private lateinit var noRepairsText: TextView
    private lateinit var searchBox: EditText
    private lateinit var statusFilter: Spinner
    private lateinit var sortSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repair_list)

        // -------------------------
        // CONNECT FIELDS
        // -------------------------

        repairList =
            findViewById(R.id.listRepairs)

        noRepairsText =
            findViewById(R.id.textNoRepairs)

        val backButton =
            findViewById<Button>(R.id.buttonBackRepairs)

        searchBox =
            findViewById(R.id.editSearchRepairs)

        statusFilter =
            findViewById(R.id.spinnerStatusFilter)

        sortSpinner =
            findViewById(R.id.spinnerSortRepairs)

        // -------------------------
        // STATUS FILTER
        // -------------------------

        val statusChoices = arrayOf(
            "All Statuses",
            "Received",
            "Diagnosing",
            "Waiting for Parts",
            "In Repair",
            "Ready for Pickup",
            "Completed"
        )

        val statusAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            statusChoices
        )

        statusAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        statusFilter.adapter = statusAdapter

        // -------------------------
        // SORT OPTIONS
        // -------------------------

        val sortChoices = arrayOf(
            "Priority: Highest First",
            "Priority: Lowest First",
            "Customer: A-Z",
            "Customer: Z-A"
        )

        val sortAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            sortChoices
        )

        sortAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        sortSpinner.adapter = sortAdapter

        // -------------------------
        // SEARCH LISTENER
        // -------------------------

        searchBox.addTextChangedListener(
            object : TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                    applyFiltersAndSort()
                }

                override fun afterTextChanged(
                    s: Editable?
                ) {
                }
            }
        )

        // -------------------------
        // STATUS FILTER LISTENER
        // -------------------------

        statusFilter.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFiltersAndSort()
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {
                }
            }

        // -------------------------
        // SORT LISTENER
        // -------------------------

        sortSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFiltersAndSort()
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {
                }
            }

        // -------------------------
        // OPEN SELECTED REPAIR
        // -------------------------

        repairList.setOnItemClickListener {
                _, _, position, _ ->

            val selectedRepair =
                filteredRepairs[position]

            val intent = Intent(
                this@RepairListActivity,
                RepairDetailActivity::class.java
            )

            // Send permanent SQLite database ID
            intent.putExtra(
                "repair_id",
                selectedRepair.id
            )

            startActivity(intent)
        }

        // -------------------------
        // BACK BUTTON
        // -------------------------

        backButton.setOnClickListener {
            finish()
        }
    }

    // -------------------------
    // REFRESH FROM SQLITE
    // -------------------------

    override fun onResume() {
        super.onResume()

        // Reload the latest repair records every time
        // this screen becomes active.
        repairs =
            RepairRepository.getRepairs(this)

        applyFiltersAndSort()
    }

    // -------------------------
    // SEARCH, FILTER, AND SORT
    // -------------------------

    private fun applyFiltersAndSort() {

        val searchText =
            searchBox.text.toString().trim()

        val selectedStatus =
            statusFilter.selectedItem?.toString()
                ?: "All Statuses"

        val selectedSort =
            sortSpinner.selectedItem?.toString()
                ?: "Priority: Highest First"

        // -------------------------
        // SEARCH SQLITE DATABASE
        // -------------------------

        var results =
            if (searchText.isEmpty()) {

                // No search entered, so use all repairs
                repairs

            } else {

                // Search SQLite directly
                RepairRepository.searchRepairs(
                    this,
                    searchText
                )
            }

        // -------------------------
        // STATUS FILTER
        // -------------------------

        results = results.filter { repair ->

            selectedStatus == "All Statuses" ||
                    repair.status == selectedStatus
        }

        // -------------------------
        // PRIORITY VALUES
        // -------------------------

        fun priorityValue(priority: String): Int {

            return when (priority) {
                "Urgent" -> 4
                "High" -> 3
                "Normal" -> 2
                "Low" -> 1
                else -> 0
            }
        }

        // -------------------------
        // SORT RESULTS
        // -------------------------

        results = when (selectedSort) {

            "Priority: Highest First" ->
                results.sortedByDescending {
                    priorityValue(it.priority)
                }

            "Priority: Lowest First" ->
                results.sortedBy {
                    priorityValue(it.priority)
                }

            "Customer: A-Z" ->
                results.sortedBy {
                    it.customerName.lowercase()
                }

            "Customer: Z-A" ->
                results.sortedByDescending {
                    it.customerName.lowercase()
                }

            else -> results
        }

        displayRepairs(results)
    }

    // -------------------------
    // DISPLAY REPAIRS
    // -------------------------

    private fun displayRepairs(
        repairsToDisplay: List<RepairTicket>
    ) {

        filteredRepairs = repairsToDisplay

        if (repairsToDisplay.isEmpty()) {

            noRepairsText.visibility = View.VISIBLE
            repairList.visibility = View.GONE

        } else {

            noRepairsText.visibility = View.GONE
            repairList.visibility = View.VISIBLE

            val repairDisplayList =
                repairsToDisplay.map { repair ->

                    "${repair.customerName}\n" +
                            "${repair.deviceType} - " +
                            "${repair.deviceModel}\n" +
                            "Status: ${repair.status}\n" +
                            "Priority: ${repair.priority}"
                }

            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_list_item_1,
                repairDisplayList
            )

            repairList.adapter = adapter
        }
    }
}