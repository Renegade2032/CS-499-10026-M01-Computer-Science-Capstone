package com.example.chrisp_helloapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RepairListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repair_list)

        val repairList = findViewById<ListView>(R.id.listRepairs)
        val noRepairsText = findViewById<TextView>(R.id.textNoRepairs)
        val backButton = findViewById<Button>(R.id.buttonBackRepairs)

        // Get all saved repairs
        val repairs = RepairRepository.getRepairs()

        if (repairs.isEmpty()) {

            noRepairsText.visibility = View.VISIBLE
            repairList.visibility = View.GONE

        } else {

            noRepairsText.visibility = View.GONE
            repairList.visibility = View.VISIBLE

            // Create readable text for each repair
            val repairDisplayList = repairs.map { repair ->
                "${repair.customerName}\n" +
                        "${repair.deviceType} - ${repair.deviceModel}\n" +
                        "Status: ${repair.status}"
            }

            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_list_item_1,
                repairDisplayList
            )

            repairList.adapter = adapter

            // Open the selected repair
            repairList.setOnItemClickListener { _, _, position, _ ->

                val intent = Intent(
                    this@RepairListActivity,
                    RepairDetailActivity::class.java
                )

                // Tell the next screen which repair was clicked
                intent.putExtra("repair_position", position)

                startActivity(intent)
            }
        }

        // Back to dashboard
        backButton.setOnClickListener {
            finish()
        }
    }
}