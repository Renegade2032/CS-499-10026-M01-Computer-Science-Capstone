package com.example.chrisp_helloapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RepairDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repair_detail)

        // Connect the fields
        val customerName =
            findViewById<EditText>(R.id.editDetailCustomerName)

        val phone =
            findViewById<EditText>(R.id.editDetailPhone)

        val deviceType =
            findViewById<EditText>(R.id.editDetailDeviceType)

        val deviceModel =
            findViewById<EditText>(R.id.editDetailDeviceModel)

        val problem =
            findViewById<EditText>(R.id.editDetailProblem)

        val statusSpinner =
            findViewById<Spinner>(R.id.spinnerDetailStatus)

        val notes =
            findViewById<EditText>(R.id.editDetailNotes)

        val saveButton =
            findViewById<Button>(R.id.buttonSaveChanges)

        val backButton =
            findViewById<Button>(R.id.buttonBackDetail)

        // Repair status choices
        val repairStatuses = arrayOf(
            "Received",
            "Diagnosing",
            "Waiting for Parts",
            "In Repair",
            "Ready for Pickup",
            "Completed"
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            repairStatuses
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        statusSpinner.adapter = adapter

        // Get the repair that was clicked
        val repairPosition =
            intent.getIntExtra("repair_position", -1)

        val repairs = RepairRepository.getRepairs()

        // Make sure the repair exists
        if (repairPosition == -1 ||
            repairPosition >= repairs.size) {

            Toast.makeText(
                this,
                "Repair could not be loaded",
                Toast.LENGTH_LONG
            ).show()

            finish()
            return
        }

        val repair = repairs[repairPosition]

        // Fill the screen with the repair information
        customerName.setText(repair.customerName)
        phone.setText(repair.phone)
        deviceType.setText(repair.deviceType)
        deviceModel.setText(repair.deviceModel)
        problem.setText(repair.problemDescription)
        notes.setText(repair.technicianNotes)

        // Select the current repair status
        val statusPosition =
            repairStatuses.indexOf(repair.status)

        if (statusPosition >= 0) {
            statusSpinner.setSelection(statusPosition)
        }

        // Back button
        backButton.setOnClickListener {
            finish()
        }

        // Save changes
        saveButton.setOnClickListener {

            val customerNameText =
                customerName.text.toString().trim()

            val phoneText =
                phone.text.toString().trim()

            val deviceTypeText =
                deviceType.text.toString().trim()

            val deviceModelText =
                deviceModel.text.toString().trim()

            val problemText =
                problem.text.toString().trim()

            val notesText =
                notes.text.toString().trim()

            val selectedStatus =
                statusSpinner.selectedItem.toString()

            // Validate required fields
            if (customerNameText.isEmpty()) {
                customerName.error =
                    "Customer name is required"
                customerName.requestFocus()
                return@setOnClickListener
            }

            if (phoneText.isEmpty()) {
                phone.error =
                    "Phone number is required"
                phone.requestFocus()
                return@setOnClickListener
            }

            if (deviceTypeText.isEmpty()) {
                deviceType.error =
                    "Device type is required"
                deviceType.requestFocus()
                return@setOnClickListener
            }

            if (deviceModelText.isEmpty()) {
                deviceModel.error =
                    "Manufacturer or model is required"
                deviceModel.requestFocus()
                return@setOnClickListener
            }

            if (problemText.isEmpty()) {
                problem.error =
                    "Problem description is required"
                problem.requestFocus()
                return@setOnClickListener
            }

            // Update the existing repair
            repair.customerName = customerNameText
            repair.phone = phoneText
            repair.deviceType = deviceTypeText
            repair.deviceModel = deviceModelText
            repair.problemDescription = problemText
            repair.status = selectedStatus
            repair.technicianNotes = notesText

            Toast.makeText(
                this,
                "Repair updated successfully",
                Toast.LENGTH_LONG
            ).show()

            finish()
        }
    }
}