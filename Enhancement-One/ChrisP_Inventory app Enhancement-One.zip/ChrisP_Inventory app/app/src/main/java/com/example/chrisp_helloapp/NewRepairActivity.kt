package com.example.chrisp_helloapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class NewRepairActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_repair)

        // Connect the form fields
        val customerName = findViewById<EditText>(R.id.editCustomerName)
        val phone = findViewById<EditText>(R.id.editPhone)
        val deviceType = findViewById<EditText>(R.id.editDeviceType)
        val deviceModel = findViewById<EditText>(R.id.editDeviceModel)
        val problem = findViewById<EditText>(R.id.editProblem)
        val notes = findViewById<EditText>(R.id.editNotes)
        val statusSpinner = findViewById<Spinner>(R.id.spinnerRepairStatus)
        val saveButton = findViewById<Button>(R.id.buttonSaveRepair)
        val backButton = findViewById<Button>(R.id.buttonBack)

        // Repair status choices
        val repairStatuses = arrayOf(
            "Received",
            "Diagnosing",
            "Waiting for Parts",
            "In Repair",
            "Ready for Pickup",
            "Completed"
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            repairStatuses
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        statusSpinner.adapter = adapter

        // Back button
        backButton.setOnClickListener {
            finish()
        }

        // Save Repair button
        saveButton.setOnClickListener {

            val customerNameText = customerName.text.toString().trim()
            val phoneText = phone.text.toString().trim()
            val deviceTypeText = deviceType.text.toString().trim()
            val deviceModelText = deviceModel.text.toString().trim()
            val problemText = problem.text.toString().trim()
            val notesText = notes.text.toString().trim()
            val selectedStatus = statusSpinner.selectedItem.toString()

            // Validate customer name
            if (customerNameText.isEmpty()) {
                customerName.error = "Customer name is required"
                customerName.requestFocus()
                return@setOnClickListener
            }

            // Validate phone number
            if (phoneText.isEmpty()) {
                phone.error = "Phone number is required"
                phone.requestFocus()
                return@setOnClickListener
            }

            // Validate device type
            if (deviceTypeText.isEmpty()) {
                deviceType.error = "Device type is required"
                deviceType.requestFocus()
                return@setOnClickListener
            }

            // Validate device model
            if (deviceModelText.isEmpty()) {
                deviceModel.error = "Manufacturer or model is required"
                deviceModel.requestFocus()
                return@setOnClickListener
            }

            // Validate problem description
            if (problemText.isEmpty()) {
                problem.error = "Problem description is required"
                problem.requestFocus()
                return@setOnClickListener
            }

            // Create the repair ticket
            val repairTicket = RepairTicket(
                customerName = customerNameText,
                phone = phoneText,
                deviceType = deviceTypeText,
                deviceModel = deviceModelText,
                problemDescription = problemText,
                status = selectedStatus,
                technicianNotes = notesText
            )

            // Add the repair ticket to the repository
            RepairRepository.addRepair(repairTicket)

            // Tell the user the repair was saved
            Toast.makeText(
                this,
                "Repair saved successfully",
                Toast.LENGTH_LONG
            ).show()

            // Return to the dashboard
            finish()
        }
    }
}