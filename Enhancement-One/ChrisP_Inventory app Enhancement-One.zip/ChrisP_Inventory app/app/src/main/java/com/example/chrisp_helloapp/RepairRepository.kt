package com.example.chrisp_helloapp

object RepairRepository {

    private val repairs = mutableListOf<RepairTicket>()

    fun addRepair(repair: RepairTicket) {
        repairs.add(repair)
    }

    fun getRepairs(): List<RepairTicket> {
        return repairs
    }
}