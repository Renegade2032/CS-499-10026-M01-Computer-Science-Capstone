package com.example.chrisp_helloapp

data class RepairTicket(
    var customerName: String,
    var phone: String,
    var deviceType: String,
    var deviceModel: String,
    var problemDescription: String,
    var status: String,
    var technicianNotes: String
)