package com.example.chrisp_helloapp

import android.graphics.Color
import android.content.res.ColorStateList
import androidx.core.graphics.drawable.DrawableCompat
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class RepairDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load the Repair Details screen
        setContentView(R.layout.activity_repair_detail)

        // Set the blue header title
        supportActionBar?.title = "Repair Details"

        // -------------------------
        // CONNECT FIELDS
        // -------------------------

        val customerName =
            findViewById<EditText>(R.id.editDetailCustomerName)

        val phone =
            findViewById<EditText>(R.id.editDetailPhone)

        val deviceType =
            findViewById<EditText>(R.id.editDetailDeviceType)

        val deviceModel =
            findViewById<EditText>(R.id.editDetailDeviceModel)

        val problem =
            findViewById<EditText>(R.id.editDetailProblem)

        val statusSpinner =
            findViewById<Spinner>(R.id.spinnerDetailStatus)

        val prioritySpinner =
            findViewById<Spinner>(R.id.spinnerDetailPriority)

        // Make the dropdown arrows white
        listOf(statusSpinner, prioritySpinner).forEach { spinner ->
            spinner.background?.let { background ->
                val tintedBackground = DrawableCompat.wrap(
                    background.mutate()
                )

                DrawableCompat.setTintList(
                    tintedBackground,
                    ColorStateList.valueOf(Color.WHITE)
                )

                spinner.background = tintedBackground
            }
        }

        val notes =
            findViewById<EditText>(R.id.editDetailNotes)

        val saveButton =
            findViewById<Button>(R.id.buttonSaveChanges)

        val deleteButton =
            findViewById<Button>(R.id.buttonDeleteRepair)

        val backButton =
            findViewById<Button>(R.id.buttonBackDetail)

        // -------------------------
        // REPAIR STATUS
        // -------------------------

        val repairStatuses = arrayOf(
            "Received",
            "Diagnosing",
            "Waiting for Parts",
            "In Repair",
            "Ready for Pickup",
            "Completed"
        )

        val statusAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            repairStatuses
        )

        statusAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        statusSpinner.adapter = statusAdapter

        // Make selected status text white
        statusSpinner.post {
            (statusSpinner.selectedView as? TextView)
                ?.setTextColor(Color.WHITE)
        }

        // -------------------------
        // REPAIR PRIORITY
        // -------------------------

        val repairPriorities = arrayOf(
            "Low",
            "Normal",
            "High",
            "Urgent"
        )

        val priorityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            repairPriorities
        )

        priorityAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        prioritySpinner.adapter = priorityAdapter

        // Make selected priority text white
        prioritySpinner.post {
            (prioritySpinner.selectedView as? TextView)
                ?.setTextColor(Color.WHITE)
        }

        // -------------------------
        // GET PERMANENT DATABASE ID
        // -------------------------

        val repairId =
            intent.getLongExtra("repair_id", -1L)

        if (repairId == -1L) {

            Toast.makeText(
                this,
                "Repair could not be loaded",
                Toast.LENGTH_LONG
            ).show()

            finish()
            return
        }

        // -------------------------
        // LOAD REPAIR FROM SQLITE
        // -------------------------

        val repair =
            RepairRepository.getRepairById(
                this,
                repairId
            )

        if (repair == null) {

            Toast.makeText(
                this,
                "Repair could not be found",
                Toast.LENGTH_LONG
            ).show()

            finish()
            return
        }

        // -------------------------
        // FILL FIELDS
        // -------------------------

        customerName.setText(repair.customerName)
        phone.setText(repair.phone)
        deviceType.setText(repair.deviceType)
        deviceModel.setText(repair.deviceModel)
        problem.setText(repair.problemDescription)
        notes.setText(repair.technicianNotes)

        // -------------------------
        // LOAD CURRENT STATUS
        // -------------------------

        val statusPosition =
            repairStatuses.indexOf(repair.status)

        if (statusPosition >= 0) {
            statusSpinner.setSelection(statusPosition)
        }

        // -------------------------
        // LOAD CURRENT PRIORITY
        // -------------------------

        val priorityPosition =
            repairPriorities.indexOf(repair.priority)

        if (priorityPosition >= 0) {
            prioritySpinner.setSelection(priorityPosition)
        }

        // -------------------------
        // BACK BUTTON
        // -------------------------

        backButton.setOnClickListener {
            finish()
        }

        // -------------------------
        // DELETE REPAIR
        // -------------------------

        deleteButton.setOnClickListener {

            AlertDialog.Builder(this)
                .setTitle("Delete Repair")
                .setMessage(
                    "Are you sure you want to delete the repair for " +
                            repair.customerName + "?"
                )
                .setPositiveButton("Delete") { _, _ ->

                    val deleted =
                        RepairRepository.deleteRepair(
                            this,
                            repair.id
                        )

                    if (deleted) {

                        Toast.makeText(
                            this,
                            "Repair deleted successfully",
                            Toast.LENGTH_LONG
                        ).show()

                        finish()

                    } else {

                        Toast.makeText(
                            this,
                            "Repair could not be deleted",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // -------------------------
        // SAVE CHANGES
        // -------------------------

        saveButton.setOnClickListener {

            val customerNameText =
                customerName.text.toString().trim()

            val phoneText =
                phone.text.toString().trim()

            val deviceTypeText =
                deviceType.text.toString().trim()

            val deviceModelText =
                deviceModel.text.toString().trim()

            val problemText =
                problem.text.toString().trim()

            val notesText =
                notes.text.toString().trim()

            val selectedStatus =
                statusSpinner.selectedItem.toString()

            val selectedPriority =
                prioritySpinner.selectedItem.toString()

            // -------------------------
            // VALIDATION
            // -------------------------

            if (customerNameText.isEmpty()) {

                customerName.error =
                    "Customer name is required"

                customerName.requestFocus()
                return@setOnClickListener
            }

            if (phoneText.isEmpty()) {

                phone.error =
                    "Phone number is required"

                phone.requestFocus()
                return@setOnClickListener
            }

            if (deviceTypeText.isEmpty()) {

                deviceType.error =
                    "Device type is required"

                deviceType.requestFocus()
                return@setOnClickListener
            }

            if (deviceModelText.isEmpty()) {

                deviceModel.error =
                    "Manufacturer or model is required"

                deviceModel.requestFocus()
                return@setOnClickListener
            }

            if (problemText.isEmpty()) {

                problem.error =
                    "Problem description is required"

                problem.requestFocus()
                return@setOnClickListener
            }

            // -------------------------
            // UPDATE REPAIR OBJECT
            // -------------------------

            repair.customerName = customerNameText
            repair.phone = phoneText
            repair.deviceType = deviceTypeText
            repair.deviceModel = deviceModelText
            repair.problemDescription = problemText
            repair.status = selectedStatus
            repair.technicianNotes = notesText
            repair.priority = selectedPriority

            // -------------------------
            // SAVE CHANGES TO SQLITE
            // -------------------------

            val updated =
                RepairRepository.updateRepair(
                    this,
                    repair
                )

            if (updated) {

                Toast.makeText(
                    this,
                    "Repair updated successfully",
                    Toast.LENGTH_LONG
                ).show()

                finish()

            } else {

                Toast.makeText(
                    this,
                    "Repair could not be updated",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
