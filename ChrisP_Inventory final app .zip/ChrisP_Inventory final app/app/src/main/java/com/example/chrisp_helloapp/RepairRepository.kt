package com.example.chrisp_helloapp

import android.content.Context
import android.database.Cursor

object RepairRepository {

    // Convert a database row into a repair ticket.
    private fun cursorToRepair(cursor: Cursor): RepairTicket {
        return RepairTicket(
            id = cursor.getLong(cursor.getColumnIndexOrThrow("id")),
            customerName = cursor.getString(cursor.getColumnIndexOrThrow("customer_name")),
            phone = cursor.getString(cursor.getColumnIndexOrThrow("phone")),
            deviceType = cursor.getString(cursor.getColumnIndexOrThrow("device_type")),
            deviceModel = cursor.getString(cursor.getColumnIndexOrThrow("device_model")),
            problemDescription = cursor.getString(cursor.getColumnIndexOrThrow("problem_description")),
            status = cursor.getString(cursor.getColumnIndexOrThrow("status")),
            technicianNotes = cursor.getString(cursor.getColumnIndexOrThrow("technician_notes")),
            priority = cursor.getString(cursor.getColumnIndexOrThrow("priority")),
            createdAt = cursor.getLong(cursor.getColumnIndexOrThrow("created_at")),
            updatedAt = cursor.getLong(cursor.getColumnIndexOrThrow("updated_at"))
        )
    }

    // Add a new repair and keep its permanent database ID.
    fun addRepair(context: Context, repair: RepairTicket): Boolean {
        val databaseHelper = DatabaseHelper(context)
        return try {
            val result = databaseHelper.addRepair(
                repair.customerName,
                repair.phone,
                repair.deviceType,
                repair.deviceModel,
                repair.problemDescription,
                repair.status,
                repair.technicianNotes,
                repair.priority
            )
            if (result != -1L) {
                repair.id = result
                true
            } else {
                false
            }
        } finally {
            databaseHelper.close()
        }
    }

    // Retrieve all saved repair tickets.
    fun getRepairs(context: Context): List<RepairTicket> {
        val databaseHelper = DatabaseHelper(context)
        return try {
            databaseHelper.getAllRepairs().use { cursor ->
                val repairs = mutableListOf<RepairTicket>()
                while (cursor.moveToNext()) {
                    repairs.add(cursorToRepair(cursor))
                }
                repairs
            }
        } finally {
            databaseHelper.close()
        }
    }

    // Search saved repair tickets through SQLite.
    fun searchRepairs(context: Context, searchText: String): List<RepairTicket> {
        val databaseHelper = DatabaseHelper(context)
        return try {
            databaseHelper.searchRepairs(searchText).use { cursor ->
                val repairs = mutableListOf<RepairTicket>()
                while (cursor.moveToNext()) {
                    repairs.add(cursorToRepair(cursor))
                }
                repairs
            }
        } finally {
            databaseHelper.close()
        }
    }

    // Retrieve one repair by its permanent database ID.
    fun getRepairById(context: Context, repairId: Long): RepairTicket? {
        val databaseHelper = DatabaseHelper(context)
        return try {
            databaseHelper.getRepairById(repairId).use { cursor ->
                if (cursor.moveToFirst()) cursorToRepair(cursor) else null
            }
        } finally {
            databaseHelper.close()
        }
    }

    // Update an existing saved repair.
    fun updateRepair(context: Context, repair: RepairTicket): Boolean {
        if (repair.id == -1L) return false

        val databaseHelper = DatabaseHelper(context)
        return try {
            databaseHelper.updateRepair(
                repair.id,
                repair.customerName,
                repair.phone,
                repair.deviceType,
                repair.deviceModel,
                repair.problemDescription,
                repair.status,
                repair.technicianNotes,
                repair.priority
            )
        } finally {
            databaseHelper.close()
        }
    }

    // Delete a saved repair by its permanent database ID.
    fun deleteRepair(context: Context, repairId: Long): Boolean {
        if (repairId == -1L) return false

        val databaseHelper = DatabaseHelper(context)
        return try {
            databaseHelper.deleteRepair(repairId)
        } finally {
            databaseHelper.close()
        }
    }
}
