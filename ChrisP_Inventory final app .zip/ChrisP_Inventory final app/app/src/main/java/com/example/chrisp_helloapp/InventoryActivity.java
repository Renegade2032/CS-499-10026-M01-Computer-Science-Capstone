package com.example.chrisp_helloapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Main inventory screen.
 * Allows users to add, update, delete, and manage
 * inventory items stored in the SQLite database.
 */
public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout inventoryTable;
    private EditText itemNameInput;
    private EditText quantityInput;
    private Button saveButton;
    private TextView selectedItemText;

    private long selectedItemId = -1;
    private int selectedQuantity = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        // Set the blue header title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Parts Inventory");
        }

        databaseHelper = new DatabaseHelper(this);

        inventoryTable = findViewById(R.id.inventoryTable);
        itemNameInput = findViewById(R.id.editTextText3);
        quantityInput = findViewById(R.id.editTextNumber3);
        saveButton = findViewById(R.id.button7);
        selectedItemText = findViewById(R.id.selectedItemText);

        // Inventory buttons
        findViewById(R.id.buttonDelete)
                .setOnClickListener(v -> deleteSelectedItem());

        findViewById(R.id.buttonIncrease)
                .setOnClickListener(v -> changeSelectedQuantity(1));

        findViewById(R.id.buttonDecrease)
                .setOnClickListener(v -> changeSelectedQuantity(-1));

        findViewById(R.id.buttonClear)
                .setOnClickListener(v -> clearSelection());

        saveButton.setOnClickListener(v -> saveItem());

        // Back button
        findViewById(R.id.buttonBack)
                .setOnClickListener(v -> finish());

        // Load inventory records
        refreshInventoryGrid();
    }

    /**
     * Add a new item or update the selected item.
     */
    private void saveItem() {

        String itemName =
                itemNameInput.getText().toString().trim();

        String quantityText =
                quantityInput.getText().toString().trim();

        if (TextUtils.isEmpty(itemName)) {
            itemNameInput.setError("Item name is required");
            return;
        }

        if (TextUtils.isEmpty(quantityText)) {
            quantityInput.setError("Quantity is required");
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            quantityInput.setError("Enter a whole number");
            return;
        }

        if (quantity < 0) {
            quantityInput.setError(
                    "Quantity cannot be negative"
            );
            return;
        }

        boolean success;

        if (selectedItemId == -1) {

            // Add new item
            success =
                    databaseHelper.addItem(
                            itemName,
                            quantity
                    ) != -1;

        } else {

            // Update existing item
            success =
                    databaseHelper.updateItem(
                            selectedItemId,
                            itemName,
                            quantity
                    );
        }

        if (success) {

            if (quantity == 0) {
                sendOutOfStockAlert(itemName);
            }

            Toast.makeText(
                    this,
                    selectedItemId == -1
                            ? "Item added"
                            : "Item updated",
                    Toast.LENGTH_SHORT
            ).show();

            clearSelection();
            refreshInventoryGrid();

        } else {

            Toast.makeText(
                    this,
                    "Unable to save item",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Delete the selected inventory item.
     */
    private void deleteSelectedItem() {

        if (selectedItemId == -1) {

            Toast.makeText(
                    this,
                    "Select an inventory row first",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (databaseHelper.deleteItem(selectedItemId)) {

            Toast.makeText(
                    this,
                    "Item deleted",
                    Toast.LENGTH_SHORT
            ).show();

            clearSelection();
            refreshInventoryGrid();
        }
    }

    /**
     * Increase or decrease the selected item's quantity.
     */
    private void changeSelectedQuantity(int change) {

        if (selectedItemId == -1) {

            Toast.makeText(
                    this,
                    "Select an inventory row first",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int newQuantity =
                Math.max(0, selectedQuantity + change);

        if (databaseHelper.updateQuantity(
                selectedItemId,
                newQuantity
        )) {

            String itemName =
                    itemNameInput.getText().toString().trim();

            boolean reachedZero =
                    selectedQuantity > 0 && newQuantity == 0;

            selectedQuantity = newQuantity;

            quantityInput.setText(
                    String.valueOf(newQuantity)
            );

            if (reachedZero) {
                sendOutOfStockAlert(itemName);
            }

            refreshInventoryGrid();
        }
    }

    /**
     * Refresh the inventory table using SQLite records.
     */
    private void refreshInventoryGrid() {

        inventoryTable.removeAllViews();

        // Add table headings
        inventoryTable.addView(createHeaderRow());

        Cursor cursor =
                databaseHelper.getAllInventory();

        try {

            int idIndex =
                    cursor.getColumnIndexOrThrow("id");

            int nameIndex =
                    cursor.getColumnIndexOrThrow("item_name");

            int quantityIndex =
                    cursor.getColumnIndexOrThrow("quantity");

            while (cursor.moveToNext()) {

                long id =
                        cursor.getLong(idIndex);

                String name =
                        cursor.getString(nameIndex);

                int quantity =
                        cursor.getInt(quantityIndex);

                inventoryTable.addView(
                        createInventoryRow(
                                id,
                                name,
                                quantity
                        )
                );
            }

        } finally {
            cursor.close();
        }
    }

    /**
     * Create the Item, Quantity, and Action headings.
     */
    private TableRow createHeaderRow() {

        TableRow row = new TableRow(this);

        row.addView(
                createCell(
                        getString(R.string.item),
                        true
                )
        );

        row.addView(
                createCell(
                        getString(R.string.quantity),
                        true
                )
        );

        row.addView(
                createCell(
                        getString(R.string.action),
                        true
                )
        );

        return row;
    }

    /**
     * Create a row for an inventory item.
     */
    private TableRow createInventoryRow(
            long id,
            String name,
            int quantity
    ) {

        TableRow row = new TableRow(this);

        row.setPadding(0, 6, 0, 6);

        // Item name
        row.addView(
                createCell(name, false)
        );

        // Quantity
        row.addView(
                createCell(
                        String.valueOf(quantity),
                        false
                )
        );

        // Select button
        Button selectButton = new Button(this);

        selectButton.setText(R.string.select);

        selectButton.setTextColor(Color.WHITE);

        selectButton.setBackgroundTintList(
                ColorStateList.valueOf(
                        Color.parseColor("#0875D1")
                )
        );

        selectButton.setOnClickListener(
                v -> selectItem(
                        id,
                        name,
                        quantity
                )
        );

        row.addView(selectButton);

        // Allow the entire row to be selected
        row.setOnClickListener(
                v -> selectItem(
                        id,
                        name,
                        quantity
                )
        );

        return row;
    }

    /**
     * Create a table cell with readable white text.
     */
    private TextView createCell(
            String text,
            boolean header
    ) {

        TextView cell = new TextView(this);

        cell.setText(text);

        // FIX: White text for all table cells
        cell.setTextColor(Color.WHITE);

        cell.setTextSize(header ? 18 : 17);

        cell.setPadding(14, 14, 14, 14);

        cell.setGravity(Gravity.CENTER_VERTICAL);

        // Make headings bold
        if (header) {
            cell.setTypeface(null, Typeface.BOLD);
        }

        // Black shadow improves readability
        cell.setShadowLayer(
                2f,
                1f,
                1f,
                Color.BLACK
        );

        cell.setLayoutParams(
                new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        return cell;
    }

    /**
     * Select an item to edit or manage its quantity.
     */
    private void selectItem(
            long id,
            String name,
            int quantity
    ) {

        selectedItemId = id;
        selectedQuantity = quantity;

        itemNameInput.setText(name);

        quantityInput.setText(
                String.valueOf(quantity)
        );

        saveButton.setText(
                R.string.update_item
        );

        selectedItemText.setText(
                getString(
                        R.string.selected_item,
                        name
                )
        );
    }

    /**
     * Clear the selected item and input fields.
     */
    private void clearSelection() {

        selectedItemId = -1;
        selectedQuantity = 0;

        itemNameInput.setText("");
        quantityInput.setText("");

        saveButton.setText(
                R.string.add_item
        );

        selectedItemText.setText(
                R.string.no_item_selected
        );
    }

    /**
     * Send an SMS alert when an item is out of stock,
     * only if SMS alerts are enabled and permitted.
     */
    private void sendOutOfStockAlert(String itemName) {

        SharedPreferences preferences =
                getSharedPreferences(
                        SmsPermissionActivity.PREFS_NAME,
                        MODE_PRIVATE
                );

        boolean enabled =
                preferences.getBoolean(
                        SmsPermissionActivity.KEY_SMS_ENABLED,
                        false
                );

        String phone =
                preferences.getString(
                        SmsPermissionActivity.KEY_PHONE,
                        ""
                );

        if (!enabled || TextUtils.isEmpty(phone)) {
            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {

            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            smsManager.sendTextMessage(
                    phone,
                    null,
                    "Inventory Tracking alert: "
                            + itemName
                            + " is out of stock and should be reordered.",
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Out-of-stock SMS alert sent",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS could not be sent, but inventory is still available",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
