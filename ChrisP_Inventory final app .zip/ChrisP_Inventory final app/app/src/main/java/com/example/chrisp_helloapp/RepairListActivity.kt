package com.example.chrisp_helloapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RepairListActivity : AppCompatActivity() {

    private var repairs: List<RepairTicket> = emptyList()
    private var filteredRepairs: List<RepairTicket> = emptyList()

    private lateinit var repairList: ListView
    private lateinit var noRepairsText: TextView
    private lateinit var searchBox: EditText
    private lateinit var statusFilter: Spinner
    private lateinit var sortSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load the Existing Repairs screen
        setContentView(R.layout.activity_repair_list)

        // Set the blue header title
        supportActionBar?.title = "Existing Repairs"

        // Connect fields
        repairList = findViewById(R.id.listRepairs)
        noRepairsText = findViewById(R.id.textNoRepairs)
        searchBox = findViewById(R.id.editSearchRepairs)
        statusFilter = findViewById(R.id.spinnerStatusFilter)
        sortSpinner = findViewById(R.id.spinnerSortRepairs)

        val backButton =
            findViewById<Button>(R.id.buttonBackRepairs)

        // Status filter choices
        val statusChoices = arrayOf(
            "All Statuses",
            "Received",
            "Diagnosing",
            "Waiting for Parts",
            "In Repair",
            "Ready for Pickup",
            "Completed"
        )

        val statusAdapter = createWhiteSpinnerAdapter(statusChoices)
        statusFilter.adapter = statusAdapter

        // Sort choices
        val sortChoices = arrayOf(
            "Priority: Highest First",
            "Priority: Lowest First",
            "Customer: A-Z",
            "Customer: Z-A"
        )

        val sortAdapter = createWhiteSpinnerAdapter(sortChoices)
        sortSpinner.adapter = sortAdapter

        // Search listener
        searchBox.addTextChangedListener(
            object : TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                    applyFiltersAndSort()
                }

                override fun afterTextChanged(s: Editable?) {
                }
            }
        )

        // Status filter listener
        statusFilter.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFiltersAndSort()
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {
                }
            }

        // Sort listener
        sortSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    applyFiltersAndSort()
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {
                }
            }

        // Open selected repair
        repairList.setOnItemClickListener { _, _, position, _ ->

            val selectedRepair = filteredRepairs[position]

            val intent = Intent(
                this@RepairListActivity,
                RepairDetailActivity::class.java
            )

            intent.putExtra("repair_id", selectedRepair.id)
            startActivity(intent)
        }

        // Back button
        backButton.setOnClickListener {
            finish()
        }
    }

    // White text for selected spinner items
    // Dark text for dropdown choices
    private fun createWhiteSpinnerAdapter(
        choices: Array<String>
    ): ArrayAdapter<String> {

        return object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            choices
        ) {

            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {

                val view = super.getView(
                    position,
                    convertView,
                    parent
                )

                val text = view as TextView

                text.setTextColor(Color.WHITE)
                text.setShadowLayer(
                    3f,
                    1f,
                    1f,
                    Color.BLACK
                )

                return view
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {

                val view = super.getDropDownView(
                    position,
                    convertView,
                    parent
                )

                val text = view as TextView

                text.setTextColor(Color.BLACK)
                text.setShadowLayer(
                    0f,
                    0f,
                    0f,
                    Color.TRANSPARENT
                )
                text.setBackgroundColor(Color.WHITE)

                return view
            }
        }.apply {
            setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )
        }
    }

    // Reload repairs from SQLite
    override fun onResume() {
        super.onResume()

        repairs = RepairRepository.getRepairs(this)
        applyFiltersAndSort()
    }

    // Search, filter, and sort
    private fun applyFiltersAndSort() {

        val searchText = searchBox.text.toString().trim()

        val selectedStatus =
            statusFilter.selectedItem?.toString()
                ?: "All Statuses"

        val selectedSort =
            sortSpinner.selectedItem?.toString()
                ?: "Priority: Highest First"

        var results =
            if (searchText.isEmpty()) {
                repairs
            } else {
                RepairRepository.searchRepairs(
                    this,
                    searchText
                )
            }

        // Filter by status
        results = results.filter { repair ->
            selectedStatus == "All Statuses" ||
                    repair.status == selectedStatus
        }

        // Priority ranking
        fun priorityValue(priority: String): Int {
            return when (priority) {
                "Urgent" -> 4
                "High" -> 3
                "Normal" -> 2
                "Low" -> 1
                else -> 0
            }
        }

        // Sort results
        results = when (selectedSort) {

            "Priority: Highest First" ->
                results.sortedByDescending {
                    priorityValue(it.priority)
                }

            "Priority: Lowest First" ->
                results.sortedBy {
                    priorityValue(it.priority)
                }

            "Customer: A-Z" ->
                results.sortedBy {
                    it.customerName.lowercase()
                }

            "Customer: Z-A" ->
                results.sortedByDescending {
                    it.customerName.lowercase()
                }

            else -> results
        }

        displayRepairs(results)
    }

    // Display repair records
    private fun displayRepairs(
        repairsToDisplay: List<RepairTicket>
    ) {

        filteredRepairs = repairsToDisplay

        if (repairsToDisplay.isEmpty()) {

            noRepairsText.visibility = View.VISIBLE
            repairList.visibility = View.GONE

        } else {

            noRepairsText.visibility = View.GONE
            repairList.visibility = View.VISIBLE

            val repairDisplayList =
                repairsToDisplay.map { repair ->

                    "${repair.customerName}\n" +
                            "${repair.deviceType} - " +
                            "${repair.deviceModel}\n" +
                            "Status: ${repair.status}\n" +
                            "Priority: ${repair.priority}"
                }

            // Custom adapter with white repair text
            val adapter = object : ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                repairDisplayList
            ) {

                override fun getView(
                    position: Int,
                    convertView: View?,
                    parent: ViewGroup
                ): View {

                    val view = super.getView(
                        position,
                        convertView,
                        parent
                    )

                    val text = view as TextView

                    text.setTextColor(Color.WHITE)
                    text.setTextSize(15f)

                    text.setShadowLayer(
                        3f,
                        1f,
                        1f,
                        Color.BLACK
                    )

                    text.setPadding(
                        16,
                        12,
                        16,
                        12
                    )

                    return view
                }
            }

            repairList.adapter = adapter
        }
    }
}
