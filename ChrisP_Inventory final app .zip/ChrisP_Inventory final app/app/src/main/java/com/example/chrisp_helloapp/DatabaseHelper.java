package com.example.chrisp_helloapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import android.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Central SQLite helper for login credentials,
 * inventory data, and repair tickets.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_tracking.db";
    private static final int DATABASE_VERSION = 3;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_INVENTORY = "inventory";
    public static final String TABLE_REPAIRS = "repairs";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL)");

        // Inventory table
        db.execSQL("CREATE TABLE " + TABLE_INVENTORY + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0))");

        // Repairs table
        db.execSQL("CREATE TABLE " + TABLE_REPAIRS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "customer_name TEXT NOT NULL, " +
                "phone TEXT NOT NULL, " +
                "device_type TEXT NOT NULL, " +
                "device_model TEXT NOT NULL, " +
                "problem_description TEXT NOT NULL, " +
                "status TEXT NOT NULL, " +
                "technician_notes TEXT, " +
                "priority TEXT NOT NULL DEFAULT 'Normal', " +
                "created_at INTEGER NOT NULL DEFAULT 0, " +
                "updated_at INTEGER NOT NULL DEFAULT 0)");
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        // Upgrade from version 1 to version 2
        // without deleting existing users or inventory.
        if (oldVersion < 2) {

            db.execSQL("CREATE TABLE IF NOT EXISTS " +
                    TABLE_REPAIRS + " (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "customer_name TEXT NOT NULL, " +
                    "phone TEXT NOT NULL, " +
                    "device_type TEXT NOT NULL, " +
                    "device_model TEXT NOT NULL, " +
                    "problem_description TEXT NOT NULL, " +
                    "status TEXT NOT NULL, " +
                    "technician_notes TEXT, " +
                    "priority TEXT NOT NULL DEFAULT 'Normal')");
        }

        // Upgrade from version 2 to version 3.
        // Add timestamps without deleting existing repair records.
        if (oldVersion < 3) {

            db.execSQL(
                    "ALTER TABLE " + TABLE_REPAIRS +
                            " ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0"
            );

            db.execSQL(
                    "ALTER TABLE " + TABLE_REPAIRS +
                            " ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0"
            );
        }
    }

    /**
     * Creates a user.
     * Returns false when the username already exists.
     */
    public boolean createUser(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.isEmpty()) {
            return false;
        }
        String encoded = encodePassword(password);
        if (encoded == null) return false;

        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash", encoded);
        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /**
     * Supports old SHA-256 accounts and upgrades them to salted PBKDF2
     * on their next successful login. Does not change repair/inventory data.
     */
    public boolean validateLogin(String username, String password) {
        if (username == null || password == null) return false;

        SQLiteDatabase db = getWritableDatabase();
        long userId;
        String stored;
        try (Cursor cursor = db.query(TABLE_USERS,
                new String[]{"id", "password_hash"}, "username = ?",
                new String[]{username.trim()}, null, null, null)) {
            if (!cursor.moveToFirst()) return false;
            userId = cursor.getLong(0);
            stored = cursor.getString(1);
        }
        if (stored == null) return false;

        if (stored.startsWith(PASSWORD_PREFIX + "$")) {
            return verifyPbkdf2(password, stored);
        }

        // Backward compatibility for passwords created by the old version.
        String legacyHash = legacySha256(password);
        boolean valid = legacyHash != null && constantTimeEqual(
                legacyHash.getBytes(StandardCharsets.UTF_8),
                stored.getBytes(StandardCharsets.UTF_8));
        // Old code had a plaintext fallback if SHA-256 was unavailable.
        if (!valid && legacyHash == null) {
            valid = constantTimeEqual(password.getBytes(StandardCharsets.UTF_8),
                    stored.getBytes(StandardCharsets.UTF_8));
        }
        if (!valid) return false;

        String upgraded = encodePassword(password);
        if (upgraded != null) {
            ContentValues values = new ContentValues();
            values.put("password_hash", upgraded);
            // Update only if the old hash has not changed in the meantime.
            db.update(TABLE_USERS, values, "id = ? AND password_hash = ?",
                    new String[]{String.valueOf(userId), stored});
        }
        return true;
    }

    // --------------------------------------------------
    // INVENTORY DATABASE METHODS
    // --------------------------------------------------

    // Get all inventory items
    public Cursor getAllInventory() {

        return getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{
                        "id",
                        "item_name",
                        "quantity"
                },
                null,
                null,
                null,
                null,
                "item_name COLLATE NOCASE ASC"
        );
    }

    // Add an inventory item
    public long addItem(
            String itemName,
            int quantity) {

        ContentValues values = new ContentValues();

        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    // Update an inventory item
    public boolean updateItem(
            long id,
            String itemName,
            int quantity) {

        ContentValues values = new ContentValues();

        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // Update inventory quantity
    public boolean updateQuantity(
            long id,
            int quantity) {

        ContentValues values = new ContentValues();

        values.put(
                "quantity",
                Math.max(0, quantity)
        );

        return getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // Delete an inventory item
    public boolean deleteItem(long id) {

        return getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // --------------------------------------------------
    // REPAIR DATABASE METHODS
    // --------------------------------------------------

    // Save a new repair ticket
    public long addRepair(
            String customerName,
            String phone,
            String deviceType,
            String deviceModel,
            String problemDescription,
            String status,
            String technicianNotes,
            String priority) {

        ContentValues values = new ContentValues();

        values.put(
                "customer_name",
                customerName.trim()
        );

        values.put(
                "phone",
                phone.trim()
        );

        values.put(
                "device_type",
                deviceType.trim()
        );

        values.put(
                "device_model",
                deviceModel.trim()
        );

        values.put(
                "problem_description",
                problemDescription.trim()
        );

        values.put(
                "status",
                status
        );

        values.put(
                "technician_notes",
                technicianNotes
        );

        values.put(
                "priority",
                priority
        );

        // Save the time this repair was created.
        long currentTime = System.currentTimeMillis();

        values.put(
                "created_at",
                currentTime
        );

        values.put(
                "updated_at",
                currentTime
        );

        // INSERT a brand-new repair record.
        return getWritableDatabase().insert(
                TABLE_REPAIRS,
                null,
                values
        );
    }

    // Get all saved repair tickets
    public Cursor getAllRepairs() {

        return getReadableDatabase().query(
                TABLE_REPAIRS,
                new String[]{
                        "id",
                        "customer_name",
                        "phone",
                        "device_type",
                        "device_model",
                        "problem_description",
                        "status",
                        "technician_notes",
                        "priority",
                        "created_at",
                        "updated_at"
                },
                null,
                null,
                null,
                null,
                "id ASC"
        );
    }

    // Get one repair ticket using its permanent database ID
    public Cursor getRepairById(long id) {

        return getReadableDatabase().query(
                TABLE_REPAIRS,
                new String[]{
                        "id",
                        "customer_name",
                        "phone",
                        "device_type",
                        "device_model",
                        "problem_description",
                        "status",
                        "technician_notes",
                        "priority",
                        "created_at",
                        "updated_at"
                },
                "id = ?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );
    }

    // Search repair tickets directly in the SQLite database
    public Cursor searchRepairs(String searchText) {

        SQLiteDatabase db = this.getReadableDatabase();

        String searchPattern = "%" + searchText + "%";

        return db.query(
                TABLE_REPAIRS,
                new String[]{
                        "id",
                        "customer_name",
                        "phone",
                        "device_type",
                        "device_model",
                        "problem_description",
                        "status",
                        "technician_notes",
                        "priority",
                        "created_at",
                        "updated_at"
                },
                "customer_name LIKE ? OR " +
                        "phone LIKE ? OR " +
                        "device_type LIKE ? OR " +
                        "device_model LIKE ?",
                new String[]{
                        searchPattern,
                        searchPattern,
                        searchPattern,
                        searchPattern
                },
                null,
                null,
                "id ASC"
        );
    }

    // Update an existing repair ticket
    public boolean updateRepair(
            long id,
            String customerName,
            String phone,
            String deviceType,
            String deviceModel,
            String problemDescription,
            String status,
            String technicianNotes,
            String priority) {

        ContentValues values = new ContentValues();

        values.put(
                "customer_name",
                customerName.trim()
        );

        values.put(
                "phone",
                phone.trim()
        );

        values.put(
                "device_type",
                deviceType.trim()
        );

        values.put(
                "device_model",
                deviceModel.trim()
        );

        values.put(
                "problem_description",
                problemDescription.trim()
        );

        values.put(
                "status",
                status
        );

        values.put(
                "technician_notes",
                technicianNotes
        );

        values.put(
                "priority",
                priority
        );

        // Change the updated time whenever this repair is edited.
        values.put(
                "updated_at",
                System.currentTimeMillis()
        );

        // UPDATE the existing repair with this ID.
        return getWritableDatabase().update(
                TABLE_REPAIRS,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // Delete a repair ticket using its permanent database ID
    public boolean deleteRepair(long id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_REPAIRS,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return rowsDeleted > 0;
    }

    // --------------------------------------------------
    // PASSWORD HASHING
    // --------------------------------------------------

    private static final String PASSWORD_PREFIX = "pbkdf2_sha256";
    private static final int PBKDF2_ITERATIONS = 210000;
    private static final int SALT_BYTES = 16;
    private static final int KEY_BITS = 256;
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private String encodePassword(String password) {
        byte[] salt = new byte[SALT_BYTES];
        SECURE_RANDOM.nextBytes(salt);
        byte[] hash = deriveKey(password, salt, PBKDF2_ITERATIONS);
        if (hash == null) return null;
        return PASSWORD_PREFIX + "$" + PBKDF2_ITERATIONS + "$"
                + Base64.encodeToString(salt, Base64.NO_WRAP) + "$"
                + Base64.encodeToString(hash, Base64.NO_WRAP);
    }

    private boolean verifyPbkdf2(String password, String stored) {
        try {
            String[] parts = stored.split("\\$", -1);
            if (parts.length != 4 || !PASSWORD_PREFIX.equals(parts[0])) return false;
            int iterations = Integer.parseInt(parts[1]);
            if (iterations < 10000 || iterations > 1000000) return false;
            byte[] salt = Base64.decode(parts[2], Base64.NO_WRAP);
            byte[] expected = Base64.decode(parts[3], Base64.NO_WRAP);
            if (salt.length != SALT_BYTES || expected.length != KEY_BITS / 8) return false;
            byte[] actual = deriveKey(password, salt, iterations);
            return actual != null && constantTimeEqual(expected, actual);
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    private byte[] deriveKey(String password, byte[] salt, int iterations) {
        char[] chars = password.toCharArray();
        PBEKeySpec spec = new PBEKeySpec(chars, salt, iterations, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException ex) {
            return null; // Fail closed; never save a plaintext password.
        } finally {
            spec.clearPassword();
            Arrays.fill(chars, '\0');
        }
    }

    private String legacySha256(String password) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder output = new StringBuilder();
            for (byte b : hash) output.append(String.format(java.util.Locale.US, "%02x", b & 0xff));
            return output.toString();
        } catch (GeneralSecurityException ex) {
            return null;
        }
    }

    private boolean constantTimeEqual(byte[] a, byte[] b) {
        return MessageDigest.isEqual(a, b);
    }
}
